<!DOCTYPE html>
<html>
<style>
body {
  background-image: url('img2.png');
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
<body>
<form action="resetpassword.php" method="POST">
  <table cellspacing='30' align='center' cellpadding="5">

  <tr>
  <b><td> <h1 style="color:green;">Enter Your Registered E-Mail ID </h1> </td></b>
  <td>===><input id="email" name="email" class="form-control input-md" type="email"></td>
  </tr>
    
  <tr>
  <b><td> <h1 style="color:green;">Enter Your Old password </h1> </td></b>
  <td>===><input id="oldpass" name="oldpass" class="form-control input-md" type="text"></td>
  </tr>

  <tr>
  <b><td><h1 style="color:green;">Enter Your New Password </h1> </td></b>
  <td>===><input id="newpass" name="newpass" type="text"></td><br><br><br><br><br><br><br>
  </tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="Submit" name="submit1"></td>
</tr>
</div>
</table>
</form>
</body>
</html>