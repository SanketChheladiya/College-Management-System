# Online-exam-system

Online examination system is a app for setup online quiz with so many functionality.
It is a PHP project.


Instalation ::

### Steps

1)Copy full folder in your web directory.

2)Import database in your phpmyadmin named project1.sql.

3)Edit dbconnection file.change username,password and database name.
- Default user is root,password is null and database name is project1.

Default admin email id is head@gmail.com and password is head .
admin password is md5 encypted.

For any query or feedback contact me at kpsagar1999@gmail.com.

Thanx.


## Precise Explanation regarding the work in detail :
INSTALLATION STEPS :
1. Copy zip file and Unzip file on your local server.
2. Put this file inside WAMP or XAMPP server.
3. Database Configuration
- Open phpmyadmin
- Create Database named project1​.
- Import database project1.sql from downloaded folder(inside database)
4. Open Your browser put inside "http://localhost/Online-Exam-System/"
5. To Login as admin put the following details.
- Admin Login Details
- Login Id: head@gmail.com
- Password: head
## ONLINE EXAMINATION SYSTEM FEATURES :
1. Login system must be present and secured by password.
2. Ability to setup multiple choice question paper. 
3. Display of quick and accurate results.
4. Rankings , and history of exams attempted can be looked after.
4. Admin panel
- Can add/remove the teachers.
- Can view the feedbacks.
 5. Teacher panel
- Can add/remove question papers.
- Can view the individual test results and overall rankings.
 6. Student panel
- Can write the exams shown in home page 
- Only once  a student can attempt the examination , after then the examination is disabled until the teacher removes it.
- Can view the overall ranking and the details of scores and examinations previously attempted.
 7. Log out after the over.
8. Users can send the suggestions and feedbacks from the home page , it can be viewed by admin.
## What makes our online exam system web project differs from others
Low internet connection would be sufficient to load the pages, since we haven’t used any picture data(using pictures the user with low internet connection takes time to load the images).
In other online exam system websites , we can find only one admin who is surely responsible for the addition or deletion of the test, but we made this site any number of authorized persons can add/remove the examinations and these all authorized persons and users of this site will be controlled by the admin.
It could be very helpful for educational institues acting as :
* Admin(headdash.php)    ---   director of institute 
* Teacher(dash.php)   ---   professors of college
* User(acccount.php)        ---   students of the college
* home page (index.php)
Security with password , even the admin cannot look at the password , ensuring the trust of the users.
A feedback system available for suggesting improvements and registering complaints.


