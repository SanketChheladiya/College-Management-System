<html>
<style>
body {
  background-image: url('Nirmacampus.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
  position: absolute;
  top: 50px;
  //right: 430px;
  left: 70px;
  padding-left: 35px;
}
</style>
      <body align="middle" background-image="Nirmacampus.jpg">
      <h1>WELCOME To Nirma University<br>
      <br>
      <br>
      <a href='sms1/index.php'><button type="submit" style="font-size: 16px;" id="login_btn" name="Admin Login" class="btn btn-default btn-block btn-custom">Admin Login</button></a>
      <br><br>
      <a href='sms1/online/index.php'><button type="submit" style="font-size: 16px;" id="login_btn" name="Admin Login" class="btn btn-default btn-block btn-custom">Student Login</button></a>
      <br><br>
      <a href='sms1/index.php'><button type="submit" style="font-size: 16px;" id="login_btn" name="Admin Login" class="btn btn-default btn-block btn-custom">Faculty Login</button></a>
      <br><br>
      <a href='sms1/index.php'><button type="submit" style="font-size: 16px;" id="login_btn" name="Admin Login" class="btn btn-default btn-block btn-custom">Student Section Login</button></a>
</html>

<?php
?>