<?php

include "layout/header.php";
include "page/student/add_student.php";
include "layout/footer.php";

?>