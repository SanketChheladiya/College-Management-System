<link rel="stylesheet" type="text/css" href="page/report/css/payment_report.css">
<script type="text/javascript" src="page/report/js/profit_report.js"></script>

<div class="row">
	
	<div class="col-md-2"></div>
	<div class="col-md-3">
        <input type="date" id="date1" value="" class="input_date" name="">
     </div>
    <div class="col-md-3">
        <input type="date" id="date2" value="" class="input_date" name="">
    </div>
      <div class="col-md-2">
            <button class="btn_select" onclick="view_profit_report()">View Report</button>
       </div>
       <div class="col-md-2"></div>

</div>


<div id="report_response">

</div>

