<script type="text/javascript" src="page/exam/js/result.js"></script>
<button onclick="fun()">fun</button>