
<link rel="stylesheet" type="text/css" href="page/index/style.css">
<script type="text/javascript" src="page/exam/js/exam.js"></script>
<div class="row" style="">
      <script type="text/javascript">
        $(document).ready(function() {
           $('table.display').DataTable();
      } );
      </script>
        
 
        <div class="col-md-12">
            <div class="dashboard_box">
                <div class="box_header">Exam List</div>
                <div class="box_body">
                   <div class="pull-rightt" style="margin-top: -20px;">
            <center><button class="button"><a href="online/index.php">+ Add Exam </button></center>
          	
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
        
    </div>  

    <style type="text/css">
    thead{
        background-color: #EFF0F2;
        border-width: 0px;
    }
    .td_list1{
        background-color: #EFF0F2;
        color: #000000;
        padding: 10px;
        font-weight: bold;
        border: 1px solid #C6C9D1;
        text-align: center;
    }
    .td_list2{
        background-color: #ffffff;
        color: #000000;
        padding: 8px;
        border: 1px solid #C6C9D1;
        text-align: center;
    }
</style>