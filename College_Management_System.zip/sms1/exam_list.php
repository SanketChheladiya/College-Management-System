<?php

include 'layout/header.php';
include 'page/exam/exam_list.php';
include 'layout/footer.php';


?>