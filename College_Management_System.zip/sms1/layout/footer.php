</div>
</div>


    <script src="style/lib/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function()
              {return false;});
        });
    </script>

  <!-- <footer style="background-color: #414959; padding: 20px;"> -->
               
<div class="footer-style custom_footer">
<center>Design & Developed By: <a class="a_footer" href="http://google.com">Sanket & Co.</a></center>
</div>
            <!-- </footer> -->
</body></html>

<style type="text/css">
 
    .custom_footer{
        padding: 10px!important;
       font-weight: bold;
       font-size: 18px;
       font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
    }
    .a_footer{
       font-size: 20px;
       color: var(--font-color);
    }
</style>