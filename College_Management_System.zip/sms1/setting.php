<?php

include 'layout/header.php';
include 'page/setting/setting.php';
include 'layout/footer.php';


?>
